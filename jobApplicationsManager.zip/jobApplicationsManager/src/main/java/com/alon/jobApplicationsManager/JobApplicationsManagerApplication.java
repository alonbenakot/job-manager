package com.alon.jobApplicationsManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobApplicationsManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobApplicationsManagerApplication.class, args);
	}

}
